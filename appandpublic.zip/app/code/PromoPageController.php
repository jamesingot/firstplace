<?php
 

class PromoPageController extends PageController
{

}