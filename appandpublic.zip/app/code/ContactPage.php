<?php

class ContactPage extends Page 
{
    
}