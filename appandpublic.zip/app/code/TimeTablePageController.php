<?php
 

class TimeTablePageController extends PageController
{

}