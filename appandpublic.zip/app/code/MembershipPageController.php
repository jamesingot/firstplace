<?php
 

class MembershipPageController extends PageController
{

}