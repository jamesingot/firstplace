<?php
  

class PromoHolder extends Page 
{
    private static $allowed_children = [
        PromoPage::class
    ];

}