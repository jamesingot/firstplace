<?php

class MembershipPage extends Page 
{
    
}