<?php
  

class HomePage extends Page 
{
  
}