<?php
 

class PromoHolderController extends PageController
{

}