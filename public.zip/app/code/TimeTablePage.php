<?php

class TimeTablePage extends Page 
{
    
}